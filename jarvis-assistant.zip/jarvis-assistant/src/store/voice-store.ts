import { create } from "zustand";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface VoiceState {
  messages: Message[];
  addMessage: (msg: Message) => void;
}

const useVoiceStore = create<VoiceState>((set) => ({
  messages: [],
  addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
}));

export default useVoiceStore;