import React from "react";

const VoiceInterface = () => {
  return (
    <div className="p-4 text-cyan-300">
      Voice Interface Placeholder
    </div>
  );
};

export default VoiceInterface;