import React from "react";

const AuthModal = () => {
  return (
    <div className="p-4 bg-gray-800 text-white rounded">
      Auth Modal Placeholder
    </div>
  );
};

export default AuthModal;