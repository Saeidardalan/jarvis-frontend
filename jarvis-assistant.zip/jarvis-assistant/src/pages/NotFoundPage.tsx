import React from "react";

const NotFoundPage = () => {
  return (
    <div className="h-screen flex items-center justify-center text-red-500">
      404 | Page not found
    </div>
  );
};

export default NotFoundPage;