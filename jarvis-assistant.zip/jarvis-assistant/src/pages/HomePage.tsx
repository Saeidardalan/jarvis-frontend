import React from "react";
import VoiceInterface from "../components/VoiceInterface";

const HomePage = () => {
  return (
    <div className="h-screen flex items-center justify-center">
      <VoiceInterface />
    </div>
  );
};

export default HomePage;