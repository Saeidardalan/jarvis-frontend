const useMobile = () => {
  return /Mobi|Android/i.test(navigator.userAgent);
};

export default useMobile;