import { useState } from "react";

const useToast = () => {
  const [message, setMessage] = useState<string | null>(null);
  const showToast = (msg: string) => setMessage(msg);
  const clearToast = () => setMessage(null);
  return { message, showToast, clearToast };
};

export default useToast;